import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ThemeToggle } from "@/components/theme-toggle";
import { 
  Sparkles, 
  FileText, 
  Target, 
  Clock, 
  Download, 
  Edit, 
  ChevronRight,
  CheckCircle,
  Zap,
  Shield
} from "lucide-react";

export default function Landing() {
  const features = [
    {
      icon: Sparkles,
      title: "AI-Powered Generation",
      description: "Advanced AI creates tailored resumes and cover letters matching your experience to job requirements",
    },
    {
      icon: Target,
      title: "Job-Specific Customization",
      description: "Paste any job description and get content optimized with relevant keywords and achievements",
    },
    {
      icon: Edit,
      title: "Easy Editing",
      description: "Refine AI-generated content with our intuitive editor before downloading",
    },
    {
      icon: Download,
      title: "Multiple Formats",
      description: "Download your documents in PDF or Word format, ready for any application",
    },
  ];

  const steps = [
    {
      number: "01",
      title: "Enter Your Info",
      description: "Fill in your work experience, education, and skills",
    },
    {
      number: "02",
      title: "Add Job Details",
      description: "Paste the job description you're applying for",
    },
    {
      number: "03",
      title: "Generate & Customize",
      description: "AI creates tailored documents you can edit",
    },
    {
      number: "04",
      title: "Download & Apply",
      description: "Get your polished resume and cover letter",
    },
  ];

  const benefits = [
    "Professional formatting that impresses recruiters",
    "Keyword optimization for applicant tracking systems",
    "Personalized cover letters for every application",
    "Multiple template styles to choose from",
    "Edit and refine before downloading",
    "Quick turnaround - ready in minutes",
  ];

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b border-border">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="flex items-center justify-center w-8 h-8 rounded-md bg-primary">
              <FileText className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="font-semibold text-lg hidden sm:block">ResumeAI</span>
          </div>
          <ThemeToggle />
        </div>
      </header>

      <main>
        <section className="relative py-24 px-6 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/10 pointer-events-none" />
          <div className="max-w-4xl mx-auto text-center relative">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium mb-6">
              <Zap className="w-4 h-4" />
              Powered by Advanced AI
            </div>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-semibold tracking-tight mb-6">
              AI-Powered Resume &<br />Cover Letter Generator
            </h1>
            <p className="text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto mb-8">
              Create professional, tailored documents in minutes. Our AI crafts compelling resumes and cover letters customized to every job you apply for.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link href="/create">
                <Button size="lg" className="gap-2 h-12 px-8 text-base" data-testid="button-get-started">
                  Get Started Free
                  <ChevronRight className="w-5 h-5" />
                </Button>
              </Link>
              <p className="text-sm text-muted-foreground">No account required</p>
            </div>
          </div>
        </section>

        <section className="py-20 px-6 bg-card border-y border-border">
          <div className="max-w-6xl mx-auto">
            <h2 className="text-2xl sm:text-3xl font-semibold text-center mb-4">
              Everything You Need to Stand Out
            </h2>
            <p className="text-muted-foreground text-center max-w-2xl mx-auto mb-12">
              Our AI-powered platform makes creating professional application documents quick and effortless
            </p>
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {features.map((feature) => {
                const Icon = feature.icon;
                return (
                  <Card key={feature.title} className="border-border">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-center w-12 h-12 rounded-lg bg-primary/10 mb-4">
                        <Icon className="w-6 h-6 text-primary" />
                      </div>
                      <h3 className="font-semibold mb-2">{feature.title}</h3>
                      <p className="text-sm text-muted-foreground">{feature.description}</p>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        </section>

        <section className="py-20 px-6">
          <div className="max-w-5xl mx-auto">
            <h2 className="text-2xl sm:text-3xl font-semibold text-center mb-4">
              How It Works
            </h2>
            <p className="text-muted-foreground text-center max-w-2xl mx-auto mb-12">
              Four simple steps to your perfect resume and cover letter
            </p>
            <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
              {steps.map((step, index) => (
                <div key={step.number} className="relative">
                  <div className="text-5xl font-bold text-primary/20 mb-4">{step.number}</div>
                  <h3 className="font-semibold mb-2">{step.title}</h3>
                  <p className="text-sm text-muted-foreground">{step.description}</p>
                  {index < steps.length - 1 && (
                    <ChevronRight className="hidden lg:block absolute top-8 -right-4 w-8 h-8 text-muted-foreground/30" />
                  )}
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-20 px-6 bg-card border-y border-border">
          <div className="max-w-4xl mx-auto">
            <div className="grid gap-12 lg:grid-cols-2 items-center">
              <div>
                <h2 className="text-2xl sm:text-3xl font-semibold mb-4">
                  Why Choose Our Platform?
                </h2>
                <p className="text-muted-foreground mb-8">
                  We combine cutting-edge AI with professional resume expertise to help you land your dream job.
                </p>
                <ul className="space-y-3">
                  {benefits.map((benefit) => (
                    <li key={benefit} className="flex items-start gap-3">
                      <CheckCircle className="w-5 h-5 text-chart-2 mt-0.5 flex-shrink-0" />
                      <span className="text-sm">{benefit}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <Card className="border-border">
                <CardContent className="p-8">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="flex items-center justify-center w-12 h-12 rounded-full bg-primary/10">
                      <Shield className="w-6 h-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Your Privacy Matters</h3>
                      <p className="text-sm text-muted-foreground">Data is processed securely</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="flex items-center justify-center w-12 h-12 rounded-full bg-primary/10">
                      <Clock className="w-6 h-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Ready in Minutes</h3>
                      <p className="text-sm text-muted-foreground">No lengthy setup required</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        <section className="py-24 px-6">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-2xl sm:text-3xl font-semibold mb-4">
              Ready to Create Your Perfect Resume?
            </h2>
            <p className="text-muted-foreground mb-8">
              Join thousands of job seekers who've landed interviews with AI-optimized resumes
            </p>
            <Link href="/create">
              <Button size="lg" className="gap-2 h-12 px-8 text-base" data-testid="button-start-creating">
                Start Creating Now
                <ChevronRight className="w-5 h-5" />
              </Button>
            </Link>
          </div>
        </section>
      </main>

      <footer className="py-8 px-6 border-t border-border">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="flex items-center justify-center w-6 h-6 rounded bg-primary">
              <FileText className="w-4 h-4 text-primary-foreground" />
            </div>
            <span className="text-sm text-muted-foreground">ResumeAI</span>
          </div>
          <p className="text-sm text-muted-foreground">
            Create professional resumes and cover letters with AI
          </p>
        </div>
      </footer>
    </div>
  );
}
