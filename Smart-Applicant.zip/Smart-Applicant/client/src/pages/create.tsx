import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "@/components/theme-toggle";
import { StepIndicator } from "@/components/step-indicator";
import { PersonalInfoForm } from "@/components/forms/personal-info-form";
import { ExperienceForm } from "@/components/forms/experience-form";
import { EducationSkillsForm } from "@/components/forms/education-skills-form";
import { JobDetailsForm } from "@/components/forms/job-details-form";
import { GenerateForm } from "@/components/forms/generate-form";
import { useResume } from "@/lib/resume-context";
import { FileText, Home } from "lucide-react";

export default function Create() {
  const { step, isGenerating } = useResume();

  const renderStep = () => {
    switch (step) {
      case 0:
        return <PersonalInfoForm />;
      case 1:
        return <ExperienceForm />;
      case 2:
        return <EducationSkillsForm />;
      case 3:
        return <JobDetailsForm />;
      case 4:
        return <GenerateForm />;
      default:
        return <PersonalInfoForm />;
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <header className="sticky top-0 z-50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b border-border">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between gap-4">
          <Link href="/">
            <div className="flex items-center gap-2 hover-elevate rounded-md p-1 -ml-1">
              <div className="flex items-center justify-center w-8 h-8 rounded-md bg-primary">
                <FileText className="w-5 h-5 text-primary-foreground" />
              </div>
              <span className="font-semibold text-lg hidden sm:block">ResumeAI</span>
            </div>
          </Link>
          <div className="flex items-center gap-2">
            <Link href="/">
              <Button variant="ghost" size="sm" className="gap-1.5" data-testid="button-home">
                <Home className="w-4 h-4" />
                <span className="hidden sm:inline">Home</span>
              </Button>
            </Link>
            <ThemeToggle />
          </div>
        </div>
      </header>

      <StepIndicator />

      <main className="flex-1 py-8 px-6">
        <div className="max-w-7xl mx-auto">
          {isGenerating ? (
            <div className="max-w-xl mx-auto text-center py-24">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-6">
                <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
              </div>
              <h2 className="text-2xl font-semibold mb-2">Creating Your Documents</h2>
              <p className="text-muted-foreground">
                Our AI is crafting your personalized resume and cover letter. This usually takes about 15-30 seconds.
              </p>
            </div>
          ) : (
            renderStep()
          )}
        </div>
      </main>
    </div>
  );
}
