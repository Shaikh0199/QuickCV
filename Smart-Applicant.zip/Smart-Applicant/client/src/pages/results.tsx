import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "@/components/theme-toggle";
import { DocumentEditor } from "@/components/document-editor";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useResume } from "@/lib/resume-context";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import {
  FileText,
  Download,
  RotateCcw,
  Home,
  ChevronDown,
  Loader2,
  FileIcon,
  FileType,
} from "lucide-react";

export default function Results() {
  const { generatedDocs, setGeneratedDocs, template, resetAll } = useResume();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [activeDocument, setActiveDocument] = useState<"resume" | "coverLetter">("resume");

  const downloadMutation = useMutation({
    mutationFn: async ({
      type,
      format,
    }: {
      type: "resume" | "coverLetter";
      format: "pdf" | "docx";
    }) => {
      const content = type === "resume" ? generatedDocs?.resume : generatedDocs?.coverLetter;
      const response = await fetch("/api/download", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content, format, type }),
      });

      if (!response.ok) {
        throw new Error("Failed to generate download");
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `${type === "resume" ? "resume" : "cover-letter"}.${format}`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    },
    onSuccess: (_, variables) => {
      toast({
        title: "Download Started",
        description: `Your ${variables.type === "resume" ? "resume" : "cover letter"} is downloading.`,
      });
    },
    onError: () => {
      toast({
        title: "Download Failed",
        description: "Failed to generate the document. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleStartOver = () => {
    resetAll();
    setLocation("/create");
  };

  const handleUpdateResume = (content: string) => {
    if (generatedDocs) {
      setGeneratedDocs({ ...generatedDocs, resume: content });
    }
  };

  const handleUpdateCoverLetter = (content: string) => {
    if (generatedDocs) {
      setGeneratedDocs({ ...generatedDocs, coverLetter: content });
    }
  };

  if (!generatedDocs) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center p-6">
        <div className="text-center max-w-md">
          <div className="flex items-center justify-center w-16 h-16 rounded-full bg-muted mx-auto mb-6">
            <FileText className="w-8 h-8 text-muted-foreground" />
          </div>
          <h1 className="text-2xl font-semibold mb-2">No Documents Generated</h1>
          <p className="text-muted-foreground mb-6">
            It looks like you haven't generated any documents yet. Start by entering your information.
          </p>
          <Link href="/create">
            <Button data-testid="button-start-fresh">Start Fresh</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <header className="sticky top-0 z-50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b border-border">
        <div className="px-4 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <Link href="/">
              <div className="flex items-center gap-2 hover-elevate rounded-md p-1 -ml-1">
                <div className="flex items-center justify-center w-8 h-8 rounded-md bg-primary">
                  <FileText className="w-5 h-5 text-primary-foreground" />
                </div>
                <span className="font-semibold text-lg hidden sm:block">ResumeAI</span>
              </div>
            </Link>
          </div>

          <div className="flex items-center gap-2 flex-wrap justify-end">
            <div className="flex bg-muted rounded-lg p-1">
              <Button
                variant={activeDocument === "resume" ? "secondary" : "ghost"}
                size="sm"
                onClick={() => setActiveDocument("resume")}
                data-testid="button-view-resume"
              >
                Resume
              </Button>
              <Button
                variant={activeDocument === "coverLetter" ? "secondary" : "ghost"}
                size="sm"
                onClick={() => setActiveDocument("coverLetter")}
                data-testid="button-view-cover-letter"
              >
                Cover Letter
              </Button>
            </div>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  className="gap-2"
                  disabled={downloadMutation.isPending}
                  data-testid="button-download"
                >
                  {downloadMutation.isPending ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Download className="w-4 h-4" />
                  )}
                  Download
                  <ChevronDown className="w-4 h-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem
                  onClick={() =>
                    downloadMutation.mutate({ type: activeDocument, format: "pdf" })
                  }
                  data-testid="menu-download-pdf"
                >
                  <FileIcon className="w-4 h-4 mr-2" />
                  Download as PDF
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={() =>
                    downloadMutation.mutate({ type: activeDocument, format: "docx" })
                  }
                  data-testid="menu-download-docx"
                >
                  <FileType className="w-4 h-4 mr-2" />
                  Download as Word
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <Button
              variant="outline"
              onClick={handleStartOver}
              className="gap-2"
              data-testid="button-start-over"
            >
              <RotateCcw className="w-4 h-4" />
              <span className="hidden sm:inline">Start Over</span>
            </Button>

            <Link href="/">
              <Button variant="ghost" size="icon" data-testid="button-home-icon">
                <Home className="w-4 h-4" />
              </Button>
            </Link>

            <ThemeToggle />
          </div>
        </div>
      </header>

      <main className="flex-1 flex overflow-hidden">
        <div className="flex-1 flex flex-col overflow-hidden">
          {activeDocument === "resume" ? (
            <DocumentEditor
              content={generatedDocs.resume}
              onChange={handleUpdateResume}
              template={template}
              title="Resume"
            />
          ) : (
            <DocumentEditor
              content={generatedDocs.coverLetter}
              onChange={handleUpdateCoverLetter}
              template={template}
              title="Cover Letter"
            />
          )}
        </div>
      </main>
    </div>
  );
}
