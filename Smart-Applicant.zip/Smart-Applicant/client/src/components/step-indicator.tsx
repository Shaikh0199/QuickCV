import { Check, User, Briefcase, GraduationCap, FileText, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";
import { useResume } from "@/lib/resume-context";

const steps = [
  { label: "Personal Info", icon: User },
  { label: "Experience", icon: Briefcase },
  { label: "Education & Skills", icon: GraduationCap },
  { label: "Job Details", icon: FileText },
  { label: "Generate", icon: Sparkles },
];

export function StepIndicator() {
  const { step, setStep, generatedDocs } = useResume();

  return (
    <div className="w-full py-4 px-6 bg-card border-b border-card-border sticky top-0 z-50">
      <div className="max-w-5xl mx-auto">
        <nav aria-label="Progress">
          <ol className="flex items-center justify-between gap-2">
            {steps.map((s, index) => {
              const Icon = s.icon;
              const isCompleted = index < step;
              const isCurrent = index === step;
              const isClickable = index <= step || generatedDocs;

              return (
                <li key={s.label} className="flex-1">
                  <button
                    onClick={() => isClickable && setStep(index)}
                    disabled={!isClickable}
                    className={cn(
                      "group flex flex-col items-center gap-2 w-full transition-colors",
                      isClickable ? "cursor-pointer" : "cursor-not-allowed opacity-50"
                    )}
                    data-testid={`step-${index}`}
                  >
                    <div
                      className={cn(
                        "flex items-center justify-center w-10 h-10 rounded-full border-2 transition-all",
                        isCompleted
                          ? "bg-primary border-primary text-primary-foreground"
                          : isCurrent
                          ? "border-primary bg-background text-primary"
                          : "border-muted bg-background text-muted-foreground"
                      )}
                    >
                      {isCompleted ? (
                        <Check className="w-5 h-5" />
                      ) : (
                        <Icon className="w-5 h-5" />
                      )}
                    </div>
                    <span
                      className={cn(
                        "text-xs font-medium text-center hidden sm:block",
                        isCurrent
                          ? "text-foreground"
                          : isCompleted
                          ? "text-muted-foreground"
                          : "text-muted-foreground"
                      )}
                    >
                      {s.label}
                    </span>
                  </button>
                  {index < steps.length - 1 && (
                    <div
                      className={cn(
                        "hidden lg:block absolute top-5 left-1/2 w-full h-0.5 -translate-y-1/2",
                        isCompleted ? "bg-primary" : "bg-muted"
                      )}
                      style={{ width: "calc(100% - 3rem)", left: "calc(50% + 1.5rem)" }}
                    />
                  )}
                </li>
              );
            })}
          </ol>
        </nav>
      </div>
    </div>
  );
}
