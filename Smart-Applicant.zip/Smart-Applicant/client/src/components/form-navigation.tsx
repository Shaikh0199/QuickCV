import { Button } from "@/components/ui/button";
import { ArrowLeft, ArrowRight, Loader2 } from "lucide-react";
import { useResume } from "@/lib/resume-context";

interface FormNavigationProps {
  onNext?: () => void;
  onBack?: () => void;
  nextLabel?: string;
  isLoading?: boolean;
  isNextDisabled?: boolean;
}

export function FormNavigation({
  onNext,
  onBack,
  nextLabel = "Save & Continue",
  isLoading = false,
  isNextDisabled = false,
}: FormNavigationProps) {
  const { step, setStep } = useResume();

  const handleBack = () => {
    if (onBack) {
      onBack();
    } else if (step > 0) {
      setStep(step - 1);
    }
  };

  const handleNext = () => {
    if (onNext) {
      onNext();
    } else {
      setStep(step + 1);
    }
  };

  return (
    <div className="flex items-center justify-between gap-4 pt-8 border-t border-border mt-8">
      {step > 0 ? (
        <Button
          type="button"
          variant="outline"
          onClick={handleBack}
          className="gap-2"
          data-testid="button-back"
        >
          <ArrowLeft className="w-4 h-4" />
          Back
        </Button>
      ) : (
        <div />
      )}
      
      <span className="text-sm text-muted-foreground hidden sm:block">
        Step {step + 1} of 5
      </span>

      <Button
        type="submit"
        onClick={onNext}
        disabled={isLoading || isNextDisabled}
        className="gap-2"
        data-testid="button-next"
      >
        {isLoading ? (
          <>
            <Loader2 className="w-4 h-4 animate-spin" />
            Processing...
          </>
        ) : (
          <>
            {nextLabel}
            <ArrowRight className="w-4 h-4" />
          </>
        )}
      </Button>
    </div>
  );
}
