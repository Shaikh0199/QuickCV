import { useMutation } from "@tanstack/react-query";
import { useResume } from "@/lib/resume-context";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Sparkles, FileText, Layout, Loader2, CheckCircle, User, Briefcase, GraduationCap, Target } from "lucide-react";
import { templateStyles, type TemplateStyle, type GenerateResponse } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";

export function GenerateForm() {
  const { resumeData, template, setTemplate, setGeneratedDocs, setIsGenerating } = useResume();
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const generateMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/generate", {
        resumeData,
        template,
      });
      return response as GenerateResponse;
    },
    onSuccess: (data) => {
      setGeneratedDocs({
        resume: data.resume,
        coverLetter: data.coverLetter,
        template,
      });
      setIsGenerating(false);
      setLocation("/results");
    },
    onError: (error: Error) => {
      setIsGenerating(false);
      toast({
        title: "Generation Failed",
        description: error.message || "Failed to generate documents. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleGenerate = () => {
    setIsGenerating(true);
    generateMutation.mutate();
  };

  const summaryItems = [
    {
      icon: User,
      label: "Personal Info",
      value: resumeData.personalInfo.fullName || "Not provided",
    },
    {
      icon: Briefcase,
      label: "Experience",
      value: `${resumeData.experiences.length} position${resumeData.experiences.length !== 1 ? "s" : ""}`,
    },
    {
      icon: GraduationCap,
      label: "Education",
      value: `${resumeData.education.length} degree${resumeData.education.length !== 1 ? "s" : ""}`,
    },
    {
      icon: Target,
      label: "Skills",
      value: `${resumeData.skills.length} skill${resumeData.skills.length !== 1 ? "s" : ""}`,
    },
  ];

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl font-semibold flex items-center gap-2">
            <Sparkles className="w-6 h-6 text-primary" />
            Generate Documents
          </CardTitle>
          <CardDescription>
            Review your information and select a template style
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-8">
          <div className="grid grid-cols-2 gap-4">
            {summaryItems.map((item) => {
              const Icon = item.icon;
              return (
                <div
                  key={item.label}
                  className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg border border-border"
                >
                  <div className="flex items-center justify-center w-10 h-10 rounded-full bg-primary/10">
                    <Icon className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground uppercase tracking-wide">
                      {item.label}
                    </p>
                    <p className="text-sm font-medium">{item.value}</p>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="space-y-4">
            <Label className="text-sm font-medium uppercase tracking-wide text-muted-foreground">
              Select Template Style
            </Label>
            <RadioGroup
              value={template}
              onValueChange={(value) => setTemplate(value as TemplateStyle)}
              className="grid gap-4 sm:grid-cols-3"
            >
              {templateStyles.map((style) => (
                <div key={style.value}>
                  <RadioGroupItem
                    value={style.value}
                    id={style.value}
                    className="peer sr-only"
                    data-testid={`radio-template-${style.value}`}
                  />
                  <Label
                    htmlFor={style.value}
                    className="flex flex-col gap-2 p-4 border-2 rounded-lg cursor-pointer transition-colors peer-data-[state=checked]:border-primary peer-data-[state=checked]:bg-primary/5 hover-elevate"
                  >
                    <div className="flex items-center gap-2">
                      <Layout className="w-5 h-5 text-muted-foreground" />
                      <span className="font-medium">{style.label}</span>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {style.description}
                    </p>
                  </Label>
                </div>
              ))}
            </RadioGroup>
          </div>

          <div className="p-4 bg-muted/50 rounded-lg border border-border">
            <div className="flex items-start gap-3">
              <CheckCircle className="w-5 h-5 text-chart-2 mt-0.5" />
              <div>
                <h4 className="text-sm font-medium">What you'll get</h4>
                <ul className="text-sm text-muted-foreground mt-2 space-y-1">
                  <li className="flex items-center gap-2">
                    <FileText className="w-3.5 h-3.5" />
                    A professionally formatted resume tailored to the job
                  </li>
                  <li className="flex items-center gap-2">
                    <FileText className="w-3.5 h-3.5" />
                    A customized cover letter addressing key requirements
                  </li>
                </ul>
              </div>
            </div>
          </div>

          <Button
            onClick={handleGenerate}
            disabled={generateMutation.isPending}
            className="w-full h-12 gap-2 text-base"
            data-testid="button-generate"
          >
            {generateMutation.isPending ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Generating with AI...
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5" />
                Generate Resume & Cover Letter
              </>
            )}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
