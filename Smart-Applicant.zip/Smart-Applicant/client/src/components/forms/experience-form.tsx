import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { experienceSchema, type Experience } from "@shared/schema";
import { useResume } from "@/lib/resume-context";
import { FormNavigation } from "@/components/form-navigation";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Briefcase, Plus, Trash2, Building2, Calendar } from "lucide-react";

const experienceFormSchema = experienceSchema.omit({ id: true }).extend({
  achievements: z.string().optional(),
});

type ExperienceFormValues = z.infer<typeof experienceFormSchema>;

export function ExperienceForm() {
  const { resumeData, setResumeData, setStep } = useResume();
  const [experiences, setExperiences] = useState<Experience[]>(resumeData.experiences);
  const [isAdding, setIsAdding] = useState(experiences.length === 0);

  const form = useForm<ExperienceFormValues>({
    resolver: zodResolver(experienceFormSchema),
    defaultValues: {
      company: "",
      position: "",
      startDate: "",
      endDate: "",
      isCurrentRole: false,
      description: "",
      achievements: "",
    },
  });

  const onAddExperience = (data: ExperienceFormValues) => {
    const newExp: Experience = {
      ...data,
      id: crypto.randomUUID(),
      achievements: data.achievements
        ? data.achievements.split("\n").filter((a) => a.trim())
        : [],
    };
    setExperiences((prev) => [...prev, newExp]);
    form.reset();
    setIsAdding(false);
  };

  const removeExperience = (id: string) => {
    setExperiences((prev) => prev.filter((e) => e.id !== id));
  };

  const handleNext = () => {
    setResumeData((prev) => ({ ...prev, experiences }));
    setStep(2);
  };

  const watchCurrentRole = form.watch("isCurrentRole");

  return (
    <Card className="max-w-3xl mx-auto">
      <CardHeader>
        <CardTitle className="text-2xl font-semibold flex items-center gap-2">
          <Briefcase className="w-6 h-6 text-primary" />
          Work Experience
        </CardTitle>
        <CardDescription>
          Add your relevant work experience, starting with the most recent
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {experiences.length > 0 && (
          <div className="space-y-4">
            {experiences.map((exp) => (
              <div
                key={exp.id}
                className="flex items-start justify-between gap-4 p-4 bg-muted/50 rounded-lg border border-border"
                data-testid={`experience-item-${exp.id}`}
              >
                <div className="flex-1 min-w-0">
                  <h4 className="font-medium text-foreground truncate">{exp.position}</h4>
                  <p className="text-sm text-muted-foreground flex items-center gap-1 mt-1">
                    <Building2 className="w-3.5 h-3.5" />
                    {exp.company}
                  </p>
                  <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                    <Calendar className="w-3 h-3" />
                    {exp.startDate} - {exp.isCurrentRole ? "Present" : exp.endDate}
                  </p>
                </div>
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={() => removeExperience(exp.id)}
                  data-testid={`button-remove-exp-${exp.id}`}
                >
                  <Trash2 className="w-4 h-4 text-destructive" />
                </Button>
              </div>
            ))}
          </div>
        )}

        {isAdding ? (
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onAddExperience)} className="space-y-6 p-4 border border-border rounded-lg bg-card">
              <div className="grid gap-6 sm:grid-cols-2">
                <FormField
                  control={form.control}
                  name="company"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-sm font-medium uppercase tracking-wide text-muted-foreground">
                        Company
                      </FormLabel>
                      <FormControl>
                        <Input
                          placeholder="Acme Inc."
                          className="h-12"
                          data-testid="input-company"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="position"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-sm font-medium uppercase tracking-wide text-muted-foreground">
                        Position
                      </FormLabel>
                      <FormControl>
                        <Input
                          placeholder="Senior Software Engineer"
                          className="h-12"
                          data-testid="input-position"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="startDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-sm font-medium uppercase tracking-wide text-muted-foreground">
                        Start Date
                      </FormLabel>
                      <FormControl>
                        <Input
                          placeholder="Jan 2020"
                          className="h-12"
                          data-testid="input-start-date"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="space-y-4">
                  <FormField
                    control={form.control}
                    name="endDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm font-medium uppercase tracking-wide text-muted-foreground">
                          End Date
                        </FormLabel>
                        <FormControl>
                          <Input
                            placeholder="Dec 2023"
                            className="h-12"
                            disabled={watchCurrentRole}
                            data-testid="input-end-date"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="isCurrentRole"
                    render={({ field }) => (
                      <FormItem className="flex items-center gap-2">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                            data-testid="checkbox-current-role"
                          />
                        </FormControl>
                        <FormLabel className="text-sm text-muted-foreground !mt-0">
                          I currently work here
                        </FormLabel>
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem className="sm:col-span-2">
                      <FormLabel className="text-sm font-medium uppercase tracking-wide text-muted-foreground">
                        Description
                      </FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Describe your role and responsibilities..."
                          className="min-h-24 resize-none"
                          data-testid="input-description"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="achievements"
                  render={({ field }) => (
                    <FormItem className="sm:col-span-2">
                      <FormLabel className="text-sm font-medium uppercase tracking-wide text-muted-foreground">
                        Key Achievements (one per line)
                      </FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Increased sales by 20%&#10;Led a team of 5 engineers&#10;Launched 3 major products"
                          className="min-h-24 resize-none"
                          data-testid="input-achievements"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="flex gap-2">
                <Button type="submit" data-testid="button-add-experience">
                  Add Experience
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsAdding(false)}
                  data-testid="button-cancel-add"
                >
                  Cancel
                </Button>
              </div>
            </form>
          </Form>
        ) : (
          <Button
            type="button"
            variant="outline"
            className="w-full gap-2 h-12 border-dashed"
            onClick={() => setIsAdding(true)}
            data-testid="button-add-another-exp"
          >
            <Plus className="w-4 h-4" />
            Add {experiences.length > 0 ? "Another" : ""} Experience
          </Button>
        )}

        <FormNavigation onNext={handleNext} />
      </CardContent>
    </Card>
  );
}
