import { useState } from "react";
import { useResume } from "@/lib/resume-context";
import { FormNavigation } from "@/components/form-navigation";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { FileText, ClipboardPaste } from "lucide-react";

export function JobDetailsForm() {
  const { resumeData, setResumeData, setStep } = useResume();
  const [jobDescription, setJobDescription] = useState(resumeData.jobDescription || "");
  const [wordCount, setWordCount] = useState(0);

  const handleChange = (value: string) => {
    setJobDescription(value);
    const words = value.trim().split(/\s+/).filter(Boolean);
    setWordCount(words.length);
  };

  const handleNext = () => {
    setResumeData((prev) => ({ ...prev, jobDescription }));
    setStep(4);
  };

  const handlePaste = async () => {
    try {
      const text = await navigator.clipboard.readText();
      handleChange(text);
    } catch (err) {
      console.error("Failed to read clipboard");
    }
  };

  return (
    <Card className="max-w-3xl mx-auto">
      <CardHeader>
        <CardTitle className="text-2xl font-semibold flex items-center gap-2">
          <FileText className="w-6 h-6 text-primary" />
          Job Description
        </CardTitle>
        <CardDescription>
          Paste the job description to tailor your resume and cover letter for this specific role
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Label
              htmlFor="jobDescription"
              className="text-sm font-medium uppercase tracking-wide text-muted-foreground"
            >
              Job Posting Content
            </Label>
            <button
              type="button"
              onClick={handlePaste}
              className="text-sm text-primary hover:underline flex items-center gap-1"
              data-testid="button-paste"
            >
              <ClipboardPaste className="w-3.5 h-3.5" />
              Paste from clipboard
            </button>
          </div>
          <Textarea
            id="jobDescription"
            placeholder="Paste the full job description here. Include the job title, responsibilities, qualifications, and any other relevant information from the posting..."
            value={jobDescription}
            onChange={(e) => handleChange(e.target.value)}
            className="min-h-48 resize-none"
            data-testid="input-job-description"
          />
          <p className="text-xs text-muted-foreground text-right">
            {wordCount} words
          </p>
        </div>

        <div className="p-4 bg-muted/50 rounded-lg border border-border">
          <h4 className="text-sm font-medium mb-2">Tips for best results:</h4>
          <ul className="text-sm text-muted-foreground space-y-1">
            <li className="flex items-start gap-2">
              <span className="text-primary mt-1">-</span>
              Include the complete job posting for better keyword matching
            </li>
            <li className="flex items-start gap-2">
              <span className="text-primary mt-1">-</span>
              Keep the job title and company name if available
            </li>
            <li className="flex items-start gap-2">
              <span className="text-primary mt-1">-</span>
              Include both required and preferred qualifications
            </li>
          </ul>
        </div>

        <FormNavigation onNext={handleNext} nextLabel="Continue to Generate" />
      </CardContent>
    </Card>
  );
}
