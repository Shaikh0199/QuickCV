import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { educationSchema, type Education } from "@shared/schema";
import { useResume } from "@/lib/resume-context";
import { FormNavigation } from "@/components/form-navigation";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { GraduationCap, Plus, Trash2, X, Building2, Calendar, Award } from "lucide-react";

const educationFormSchema = educationSchema.omit({ id: true });
type EducationFormValues = z.infer<typeof educationFormSchema>;

export function EducationSkillsForm() {
  const { resumeData, setResumeData, setStep } = useResume();
  const [education, setEducation] = useState<Education[]>(resumeData.education);
  const [skills, setSkills] = useState<string[]>(resumeData.skills);
  const [skillInput, setSkillInput] = useState("");
  const [isAddingEducation, setIsAddingEducation] = useState(education.length === 0);

  const form = useForm<EducationFormValues>({
    resolver: zodResolver(educationFormSchema),
    defaultValues: {
      institution: "",
      degree: "",
      field: "",
      graduationDate: "",
      gpa: "",
      honors: "",
    },
  });

  const onAddEducation = (data: EducationFormValues) => {
    const newEdu: Education = {
      ...data,
      id: crypto.randomUUID(),
    };
    setEducation((prev) => [...prev, newEdu]);
    form.reset();
    setIsAddingEducation(false);
  };

  const removeEducation = (id: string) => {
    setEducation((prev) => prev.filter((e) => e.id !== id));
  };

  const addSkill = () => {
    if (skillInput.trim() && !skills.includes(skillInput.trim())) {
      setSkills((prev) => [...prev, skillInput.trim()]);
      setSkillInput("");
    }
  };

  const removeSkill = (skill: string) => {
    setSkills((prev) => prev.filter((s) => s !== skill));
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      e.preventDefault();
      addSkill();
    }
  };

  const handleNext = () => {
    setResumeData((prev) => ({ ...prev, education, skills }));
    setStep(3);
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl font-semibold flex items-center gap-2">
            <GraduationCap className="w-6 h-6 text-primary" />
            Education
          </CardTitle>
          <CardDescription>
            Add your educational background
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {education.length > 0 && (
            <div className="space-y-4">
              {education.map((edu) => (
                <div
                  key={edu.id}
                  className="flex items-start justify-between gap-4 p-4 bg-muted/50 rounded-lg border border-border"
                  data-testid={`education-item-${edu.id}`}
                >
                  <div className="flex-1 min-w-0">
                    <h4 className="font-medium text-foreground truncate">
                      {edu.degree} in {edu.field}
                    </h4>
                    <p className="text-sm text-muted-foreground flex items-center gap-1 mt-1">
                      <Building2 className="w-3.5 h-3.5" />
                      {edu.institution}
                    </p>
                    <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                      <Calendar className="w-3 h-3" />
                      {edu.graduationDate}
                      {edu.gpa && (
                        <>
                          <span className="mx-1">|</span>
                          <Award className="w-3 h-3" />
                          GPA: {edu.gpa}
                        </>
                      )}
                    </p>
                  </div>
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    onClick={() => removeEducation(edu.id)}
                    data-testid={`button-remove-edu-${edu.id}`}
                  >
                    <Trash2 className="w-4 h-4 text-destructive" />
                  </Button>
                </div>
              ))}
            </div>
          )}

          {isAddingEducation ? (
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onAddEducation)} className="space-y-6 p-4 border border-border rounded-lg bg-card">
                <div className="grid gap-6 sm:grid-cols-2">
                  <FormField
                    control={form.control}
                    name="institution"
                    render={({ field }) => (
                      <FormItem className="sm:col-span-2">
                        <FormLabel className="text-sm font-medium uppercase tracking-wide text-muted-foreground">
                          Institution
                        </FormLabel>
                        <FormControl>
                          <Input
                            placeholder="Stanford University"
                            className="h-12"
                            data-testid="input-institution"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="degree"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm font-medium uppercase tracking-wide text-muted-foreground">
                          Degree
                        </FormLabel>
                        <FormControl>
                          <Input
                            placeholder="Bachelor of Science"
                            className="h-12"
                            data-testid="input-degree"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="field"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm font-medium uppercase tracking-wide text-muted-foreground">
                          Field of Study
                        </FormLabel>
                        <FormControl>
                          <Input
                            placeholder="Computer Science"
                            className="h-12"
                            data-testid="input-field"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="graduationDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm font-medium uppercase tracking-wide text-muted-foreground">
                          Graduation Date
                        </FormLabel>
                        <FormControl>
                          <Input
                            placeholder="May 2020"
                            className="h-12"
                            data-testid="input-graduation-date"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="gpa"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm font-medium uppercase tracking-wide text-muted-foreground">
                          GPA (Optional)
                        </FormLabel>
                        <FormControl>
                          <Input
                            placeholder="3.8"
                            className="h-12"
                            data-testid="input-gpa"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="honors"
                    render={({ field }) => (
                      <FormItem className="sm:col-span-2">
                        <FormLabel className="text-sm font-medium uppercase tracking-wide text-muted-foreground">
                          Honors & Awards (Optional)
                        </FormLabel>
                        <FormControl>
                          <Input
                            placeholder="Summa Cum Laude, Dean's List"
                            className="h-12"
                            data-testid="input-honors"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="flex gap-2">
                  <Button type="submit" data-testid="button-add-education">
                    Add Education
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setIsAddingEducation(false)}
                    data-testid="button-cancel-add-edu"
                  >
                    Cancel
                  </Button>
                </div>
              </form>
            </Form>
          ) : (
            <Button
              type="button"
              variant="outline"
              className="w-full gap-2 h-12 border-dashed"
              onClick={() => setIsAddingEducation(true)}
              data-testid="button-add-another-edu"
            >
              <Plus className="w-4 h-4" />
              Add {education.length > 0 ? "Another" : ""} Education
            </Button>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-xl font-semibold">Skills</CardTitle>
          <CardDescription>
            Add your technical and professional skills
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Input
              placeholder="e.g., JavaScript, Project Management, Data Analysis"
              value={skillInput}
              onChange={(e) => setSkillInput(e.target.value)}
              onKeyDown={handleKeyDown}
              className="h-12 flex-1"
              data-testid="input-skill"
            />
            <Button
              type="button"
              onClick={addSkill}
              disabled={!skillInput.trim()}
              data-testid="button-add-skill"
            >
              <Plus className="w-4 h-4" />
            </Button>
          </div>

          {skills.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {skills.map((skill) => (
                <Badge
                  key={skill}
                  variant="secondary"
                  className="gap-1 pr-1"
                  data-testid={`skill-badge-${skill}`}
                >
                  {skill}
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="h-4 w-4 p-0 no-default-hover-elevate"
                    onClick={() => removeSkill(skill)}
                    data-testid={`button-remove-skill-${skill}`}
                  >
                    <X className="w-3 h-3" />
                  </Button>
                </Badge>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <FormNavigation onNext={handleNext} />
    </div>
  );
}
