import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { DocumentPreview } from "@/components/document-preview";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Edit3, Eye, Save, RotateCcw } from "lucide-react";
import type { TemplateStyle } from "@shared/schema";

interface DocumentEditorProps {
  content: string;
  onChange: (content: string) => void;
  template: TemplateStyle;
  title: string;
}

export function DocumentEditor({ content, onChange, template, title }: DocumentEditorProps) {
  const [localContent, setLocalContent] = useState(content);
  const [activeTab, setActiveTab] = useState<"edit" | "preview">("preview");
  const [hasChanges, setHasChanges] = useState(false);
  const originalContent = useRef(content);

  useEffect(() => {
    setLocalContent(content);
    originalContent.current = content;
    setHasChanges(false);
  }, [content]);

  const handleChange = (value: string) => {
    setLocalContent(value);
    setHasChanges(value !== originalContent.current);
  };

  const handleSave = () => {
    onChange(localContent);
    originalContent.current = localContent;
    setHasChanges(false);
    setActiveTab("preview");
  };

  const handleReset = () => {
    setLocalContent(originalContent.current);
    setHasChanges(false);
  };

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between gap-4 p-3 border-b border-border bg-card">
        <h3 className="font-medium text-sm">{title}</h3>
        <div className="flex items-center gap-2">
          {hasChanges && (
            <>
              <Button
                size="sm"
                variant="outline"
                onClick={handleReset}
                className="gap-1"
                data-testid="button-reset-changes"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                Reset
              </Button>
              <Button
                size="sm"
                onClick={handleSave}
                className="gap-1"
                data-testid="button-save-changes"
              >
                <Save className="w-3.5 h-3.5" />
                Save
              </Button>
            </>
          )}
        </div>
      </div>

      <Tabs
        value={activeTab}
        onValueChange={(v) => setActiveTab(v as "edit" | "preview")}
        className="flex-1 flex flex-col"
      >
        <div className="px-3 pt-2 border-b border-border bg-card">
          <TabsList className="h-9">
            <TabsTrigger value="preview" className="gap-1.5" data-testid="tab-preview">
              <Eye className="w-3.5 h-3.5" />
              Preview
            </TabsTrigger>
            <TabsTrigger value="edit" className="gap-1.5" data-testid="tab-edit">
              <Edit3 className="w-3.5 h-3.5" />
              Edit
            </TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="preview" className="flex-1 m-0 p-4 bg-muted/30 overflow-hidden">
          <DocumentPreview content={localContent} template={template} />
        </TabsContent>

        <TabsContent value="edit" className="flex-1 m-0 p-4 overflow-hidden">
          <Textarea
            value={localContent}
            onChange={(e) => handleChange(e.target.value)}
            className="h-full w-full resize-none font-mono text-sm"
            placeholder="Edit your document content here..."
            data-testid="textarea-edit-document"
          />
        </TabsContent>
      </Tabs>
    </div>
  );
}
