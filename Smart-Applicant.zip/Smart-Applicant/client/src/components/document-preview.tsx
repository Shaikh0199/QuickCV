import { cn } from "@/lib/utils";
import { ScrollArea } from "@/components/ui/scroll-area";

interface DocumentPreviewProps {
  content: string;
  className?: string;
  template?: "modern" | "classic" | "minimal";
}

export function DocumentPreview({ content, className, template = "modern" }: DocumentPreviewProps) {
  const templateStyles = {
    modern: "font-sans",
    classic: "font-serif",
    minimal: "font-sans tracking-wide",
  };

  return (
    <ScrollArea className={cn("h-full w-full", className)}>
      <div
        className={cn(
          "bg-white dark:bg-gray-50 shadow-lg rounded-lg p-12 min-h-full text-gray-900",
          templateStyles[template]
        )}
        style={{
          maxWidth: "8.5in",
          minHeight: "11in",
          margin: "0 auto",
        }}
      >
        <div
          className="prose prose-sm max-w-none prose-headings:text-gray-900 prose-p:text-gray-700 prose-li:text-gray-700"
          dangerouslySetInnerHTML={{ __html: formatContent(content, template) }}
        />
      </div>
    </ScrollArea>
  );
}

function formatContent(content: string, template: string): string {
  if (!content) return "";

  let html = content
    .replace(/^### (.+)$/gm, '<h3 class="text-lg font-semibold mt-6 mb-2 border-b pb-1">$1</h3>')
    .replace(/^## (.+)$/gm, '<h2 class="text-xl font-bold mt-8 mb-3">$2</h2>')
    .replace(/^# (.+)$/gm, '<h1 class="text-2xl font-bold mb-4">$1</h1>')
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.+?)\*/g, '<em>$1</em>')
    .replace(/^- (.+)$/gm, '<li class="ml-4">$1</li>')
    .replace(/(<li.*<\/li>\n?)+/g, '<ul class="list-disc mb-4">$&</ul>')
    .replace(/\n\n/g, '</p><p class="mb-3">')
    .replace(/\n/g, '<br/>');

  if (!html.startsWith('<')) {
    html = '<p class="mb-3">' + html + '</p>';
  }

  if (template === "modern") {
    html = html.replace(/<h1/g, '<h1 class="text-primary"');
  } else if (template === "classic") {
    html = html.replace(/<h3/g, '<h3 class="text-sm uppercase tracking-wider"');
  }

  return html;
}
