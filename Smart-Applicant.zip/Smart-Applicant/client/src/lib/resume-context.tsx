import { createContext, useContext, useState, type ReactNode } from "react";
import type { ResumeData, GeneratedDocuments, TemplateStyle } from "@shared/schema";

interface ResumeContextType {
  step: number;
  setStep: (step: number) => void;
  resumeData: ResumeData;
  setResumeData: (data: ResumeData | ((prev: ResumeData) => ResumeData)) => void;
  generatedDocs: GeneratedDocuments | null;
  setGeneratedDocs: (docs: GeneratedDocuments | null) => void;
  template: TemplateStyle;
  setTemplate: (template: TemplateStyle) => void;
  isGenerating: boolean;
  setIsGenerating: (generating: boolean) => void;
  resetAll: () => void;
}

const defaultResumeData: ResumeData = {
  personalInfo: {
    fullName: "",
    email: "",
    phone: "",
    location: "",
    linkedIn: "",
    website: "",
    summary: "",
  },
  experiences: [],
  education: [],
  skills: [],
  jobDescription: "",
};

const ResumeContext = createContext<ResumeContextType | null>(null);

export function ResumeProvider({ children }: { children: ReactNode }) {
  const [step, setStep] = useState(0);
  const [resumeData, setResumeData] = useState<ResumeData>(defaultResumeData);
  const [generatedDocs, setGeneratedDocs] = useState<GeneratedDocuments | null>(null);
  const [template, setTemplate] = useState<TemplateStyle>("modern");
  const [isGenerating, setIsGenerating] = useState(false);

  const resetAll = () => {
    setStep(0);
    setResumeData(defaultResumeData);
    setGeneratedDocs(null);
    setTemplate("modern");
    setIsGenerating(false);
  };

  return (
    <ResumeContext.Provider
      value={{
        step,
        setStep,
        resumeData,
        setResumeData,
        generatedDocs,
        setGeneratedDocs,
        template,
        setTemplate,
        isGenerating,
        setIsGenerating,
        resetAll,
      }}
    >
      {children}
    </ResumeContext.Provider>
  );
}

export function useResume() {
  const context = useContext(ResumeContext);
  if (!context) {
    throw new Error("useResume must be used within a ResumeProvider");
  }
  return context;
}
