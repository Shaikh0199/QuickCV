import type { Express } from "express";
import { createServer, type Server } from "http";
import { generateResume, generateCoverLetter } from "./openai";
import { generateRequestSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  app.post("/api/generate", async (req, res) => {
    try {
      const parsed = generateRequestSchema.safeParse(req.body);
      
      if (!parsed.success) {
        return res.status(400).json({ 
          message: "Invalid request data",
          errors: parsed.error.errors 
        });
      }

      const { resumeData, template } = parsed.data;

      const [resume, coverLetter] = await Promise.all([
        generateResume(resumeData, template),
        generateCoverLetter(resumeData, template),
      ]);

      res.json({ resume, coverLetter });
    } catch (error) {
      console.error("Generation error:", error);
      
      let message = "Failed to generate documents";
      let statusCode = 500;
      
      if (error instanceof Error) {
        const errorMessage = error.message.toLowerCase();
        
        if (errorMessage.includes("429") || errorMessage.includes("quota") || errorMessage.includes("rate limit")) {
          message = "The AI service is temporarily unavailable due to usage limits. Please try again in a few minutes.";
          statusCode = 429;
        } else if (errorMessage.includes("401") || errorMessage.includes("api key") || errorMessage.includes("unauthorized")) {
          message = "There's an issue with the AI service configuration. Please contact support.";
          statusCode = 401;
        } else if (errorMessage.includes("timeout") || errorMessage.includes("timed out")) {
          message = "The request took too long. Please try again.";
          statusCode = 504;
        } else {
          message = "An error occurred while generating your documents. Please try again.";
        }
      }
      
      res.status(statusCode).json({ message });
    }
  });

  const downloadSchema = z.object({
    content: z.string(),
    format: z.enum(["pdf", "docx"]),
    type: z.enum(["resume", "coverLetter"]),
  });

  app.post("/api/download", async (req, res) => {
    try {
      const parsed = downloadSchema.safeParse(req.body);
      
      if (!parsed.success) {
        return res.status(400).json({ 
          message: "Invalid request data",
          errors: parsed.error.errors 
        });
      }

      const { content, format, type } = parsed.data;

      if (format === "pdf") {
        const htmlContent = convertMarkdownToHtml(content);
        const pdfBuffer = await generatePdfFromHtml(htmlContent);
        
        res.setHeader("Content-Type", "application/pdf");
        res.setHeader(
          "Content-Disposition",
          `attachment; filename="${type === "resume" ? "resume" : "cover-letter"}.pdf"`
        );
        res.send(pdfBuffer);
      } else {
        const docxBuffer = await generateDocx(content);
        
        res.setHeader(
          "Content-Type",
          "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        );
        res.setHeader(
          "Content-Disposition",
          `attachment; filename="${type === "resume" ? "resume" : "cover-letter"}.docx"`
        );
        res.send(docxBuffer);
      }
    } catch (error) {
      console.error("Download error:", error);
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to generate download" 
      });
    }
  });

  return httpServer;
}

function convertMarkdownToHtml(markdown: string): string {
  let html = markdown
    .replace(/^### (.+)$/gm, '<h3 style="font-size: 14px; font-weight: 600; margin-top: 16px; margin-bottom: 8px; border-bottom: 1px solid #e5e5e5; padding-bottom: 4px;">$1</h3>')
    .replace(/^## (.+)$/gm, '<h2 style="font-size: 16px; font-weight: 700; margin-top: 20px; margin-bottom: 10px;">$1</h2>')
    .replace(/^# (.+)$/gm, '<h1 style="font-size: 20px; font-weight: 700; margin-bottom: 12px;">$1</h1>')
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.+?)\*/g, '<em>$1</em>')
    .replace(/^- (.+)$/gm, '<li style="margin-left: 20px; margin-bottom: 4px;">$1</li>')
    .replace(/\n\n/g, '</p><p style="margin-bottom: 10px;">')
    .replace(/\n/g, '<br/>');

  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      <style>
        body {
          font-family: 'Helvetica Neue', Arial, sans-serif;
          font-size: 11px;
          line-height: 1.5;
          color: #333;
          max-width: 8.5in;
          margin: 0 auto;
          padding: 0.5in;
        }
        p { margin-bottom: 10px; }
        ul { padding-left: 0; list-style: none; }
        li::before { content: "• "; }
      </style>
    </head>
    <body>
      ${html}
    </body>
    </html>
  `;
}

async function generatePdfFromHtml(html: string): Promise<Buffer> {
  const textContent = html
    .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '')
    .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '')
    .replace(/<[^>]+>/g, '\n')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
  
  const pdfHeader = Buffer.from('%PDF-1.4\n');
  const pdfBody = Buffer.from(`
1 0 obj
<< /Type /Catalog /Pages 2 0 R >>
endobj

2 0 obj
<< /Type /Pages /Kids [3 0 R] /Count 1 >>
endobj

3 0 obj
<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>
endobj

4 0 obj
<< /Length ${textContent.length + 100} >>
stream
BT
/F1 10 Tf
50 750 Td
12 TL
${textContent.split('\n').slice(0, 50).map(line => `(${line.replace(/[()\\]/g, '\\$&').substring(0, 80)}) Tj T*`).join('\n')}
ET
endstream
endobj

5 0 obj
<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>
endobj

xref
0 6
0000000000 65535 f 
0000000009 00000 n 
0000000058 00000 n 
0000000115 00000 n 
0000000266 00000 n 
trailer
<< /Size 6 /Root 1 0 R >>
startxref
${500 + textContent.length}
%%EOF
`);

  return Buffer.concat([pdfHeader, pdfBody]);
}

async function generateDocx(content: string): Promise<Buffer> {
  const textContent = content
    .replace(/^### (.+)$/gm, '\n$1\n' + '─'.repeat(40) + '\n')
    .replace(/^## (.+)$/gm, '\n$1\n')
    .replace(/^# (.+)$/gm, '\n$1\n')
    .replace(/\*\*(.+?)\*\*/g, '$1')
    .replace(/\*(.+?)\*/g, '$1')
    .replace(/^- /gm, '• ');

  return Buffer.from(textContent, 'utf-8');
}
