import OpenAI from "openai";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
function getOpenAIClient(): OpenAI {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    throw new Error("OPENAI_API_KEY is not configured. Please set the API key in your environment.");
  }
  return new OpenAI({ apiKey });
}

interface ResumeData {
  personalInfo: {
    fullName: string;
    email: string;
    phone: string;
    location: string;
    linkedIn?: string;
    website?: string;
    summary?: string;
  };
  experiences: Array<{
    company: string;
    position: string;
    startDate: string;
    endDate?: string;
    isCurrentRole: boolean;
    description?: string;
    achievements: string[];
  }>;
  education: Array<{
    institution: string;
    degree: string;
    field: string;
    graduationDate: string;
    gpa?: string;
    honors?: string;
  }>;
  skills: string[];
  jobDescription?: string;
}

export async function generateResume(
  data: ResumeData,
  template: "modern" | "classic" | "minimal"
): Promise<string> {
  const templateInstructions = {
    modern: "Use a clean, contemporary format with clear section headers and bullet points. Focus on achievements and metrics.",
    classic: "Use a traditional professional format with formal language and chronological organization.",
    minimal: "Use a simple, elegant format with minimal formatting. Focus on essential information only.",
  };

  const prompt = `You are an expert resume writer. Create a professional resume based on the following information.

CANDIDATE INFORMATION:
Name: ${data.personalInfo.fullName}
Email: ${data.personalInfo.email}
Phone: ${data.personalInfo.phone}
Location: ${data.personalInfo.location}
${data.personalInfo.linkedIn ? `LinkedIn: ${data.personalInfo.linkedIn}` : ""}
${data.personalInfo.website ? `Website: ${data.personalInfo.website}` : ""}
${data.personalInfo.summary ? `Summary: ${data.personalInfo.summary}` : ""}

WORK EXPERIENCE:
${data.experiences
  .map(
    (exp) => `
- ${exp.position} at ${exp.company}
  ${exp.startDate} - ${exp.isCurrentRole ? "Present" : exp.endDate || "N/A"}
  ${exp.description || ""}
  ${exp.achievements.length > 0 ? "Achievements: " + exp.achievements.join("; ") : ""}
`
  )
  .join("\n")}

EDUCATION:
${data.education
  .map(
    (edu) => `
- ${edu.degree} in ${edu.field}
  ${edu.institution}, ${edu.graduationDate}
  ${edu.gpa ? `GPA: ${edu.gpa}` : ""}
  ${edu.honors ? `Honors: ${edu.honors}` : ""}
`
  )
  .join("\n")}

SKILLS: ${data.skills.join(", ")}

${data.jobDescription ? `TARGET JOB DESCRIPTION:\n${data.jobDescription}` : ""}

TEMPLATE STYLE: ${templateInstructions[template]}

Create a compelling, ATS-friendly resume that:
1. Highlights relevant experience and achievements
2. Uses action verbs and quantifiable results where possible
3. Incorporates keywords from the job description if provided
4. Is well-organized and easy to scan
5. Uses markdown formatting with headers (###) for sections

Output the resume in clean markdown format.`;

  const openai = getOpenAIClient();
  const response = await openai.chat.completions.create({
    model: "gpt-5",
    messages: [{ role: "user", content: prompt }],
    max_completion_tokens: 2048,
  });

  return response.choices[0].message.content || "";
}

export async function generateCoverLetter(
  data: ResumeData,
  template: "modern" | "classic" | "minimal"
): Promise<string> {
  const templateInstructions = {
    modern: "Write in a conversational yet professional tone. Be engaging and show personality while remaining professional.",
    classic: "Write in a formal, traditional business letter style with proper salutations and closings.",
    minimal: "Write concisely and directly. Get to the point quickly while maintaining professionalism.",
  };

  const prompt = `You are an expert cover letter writer. Create a compelling cover letter based on the following information.

CANDIDATE INFORMATION:
Name: ${data.personalInfo.fullName}
Email: ${data.personalInfo.email}
Phone: ${data.personalInfo.phone}
Location: ${data.personalInfo.location}

RELEVANT EXPERIENCE:
${data.experiences
  .slice(0, 3)
  .map(
    (exp) => `
- ${exp.position} at ${exp.company} (${exp.startDate} - ${exp.isCurrentRole ? "Present" : exp.endDate})
  ${exp.description || ""}
  ${exp.achievements.length > 0 ? "Key achievements: " + exp.achievements.join("; ") : ""}
`
  )
  .join("\n")}

EDUCATION:
${data.education
  .slice(0, 2)
  .map((edu) => `- ${edu.degree} in ${edu.field} from ${edu.institution}`)
  .join("\n")}

KEY SKILLS: ${data.skills.slice(0, 10).join(", ")}

${data.jobDescription ? `JOB DESCRIPTION:\n${data.jobDescription}` : ""}

TEMPLATE STYLE: ${templateInstructions[template]}

Create a compelling cover letter that:
1. Opens with a strong, attention-grabbing introduction
2. Demonstrates knowledge of the company/role (if job description provided)
3. Connects the candidate's experience to the job requirements
4. Highlights 2-3 key achievements or qualifications
5. Shows enthusiasm and cultural fit
6. Ends with a clear call to action
7. Is 3-4 paragraphs, approximately 300-400 words

Use markdown formatting. Start with the date and contact info, then the letter body.`;

  const openai = getOpenAIClient();
  const response = await openai.chat.completions.create({
    model: "gpt-5",
    messages: [{ role: "user", content: prompt }],
    max_completion_tokens: 1500,
  });

  return response.choices[0].message.content || "";
}
