import { z } from "zod";

// Personal Information
export const personalInfoSchema = z.object({
  fullName: z.string().min(1, "Full name is required"),
  email: z.string().email("Valid email is required"),
  phone: z.string().min(1, "Phone number is required"),
  location: z.string().min(1, "Location is required"),
  linkedIn: z.string().optional(),
  website: z.string().optional(),
  summary: z.string().optional(),
});

export type PersonalInfo = z.infer<typeof personalInfoSchema>;

// Work Experience
export const experienceSchema = z.object({
  id: z.string(),
  company: z.string().min(1, "Company name is required"),
  position: z.string().min(1, "Position is required"),
  startDate: z.string().min(1, "Start date is required"),
  endDate: z.string().optional(),
  isCurrentRole: z.boolean().default(false),
  description: z.string().optional(),
  achievements: z.array(z.string()).default([]),
});

export type Experience = z.infer<typeof experienceSchema>;

// Education
export const educationSchema = z.object({
  id: z.string(),
  institution: z.string().min(1, "Institution is required"),
  degree: z.string().min(1, "Degree is required"),
  field: z.string().min(1, "Field of study is required"),
  graduationDate: z.string().min(1, "Graduation date is required"),
  gpa: z.string().optional(),
  honors: z.string().optional(),
});

export type Education = z.infer<typeof educationSchema>;

// Complete Resume Data
export const resumeDataSchema = z.object({
  personalInfo: personalInfoSchema,
  experiences: z.array(experienceSchema).default([]),
  education: z.array(educationSchema).default([]),
  skills: z.array(z.string()).default([]),
  jobDescription: z.string().optional(),
});

export type ResumeData = z.infer<typeof resumeDataSchema>;

// Generated Documents
export const generatedDocumentsSchema = z.object({
  resume: z.string(),
  coverLetter: z.string(),
  template: z.enum(["modern", "classic", "minimal"]).default("modern"),
});

export type GeneratedDocuments = z.infer<typeof generatedDocumentsSchema>;

// API Request/Response Types
export const generateRequestSchema = z.object({
  resumeData: resumeDataSchema,
  template: z.enum(["modern", "classic", "minimal"]).default("modern"),
});

export type GenerateRequest = z.infer<typeof generateRequestSchema>;

export const generateResponseSchema = z.object({
  resume: z.string(),
  coverLetter: z.string(),
});

export type GenerateResponse = z.infer<typeof generateResponseSchema>;

// Template types
export type TemplateStyle = "modern" | "classic" | "minimal";

export const templateStyles: { value: TemplateStyle; label: string; description: string }[] = [
  { value: "modern", label: "Modern", description: "Clean lines with a contemporary feel" },
  { value: "classic", label: "Classic", description: "Traditional professional formatting" },
  { value: "minimal", label: "Minimal", description: "Simple and elegant design" },
];
